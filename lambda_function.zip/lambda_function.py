import json
import boto3
import os
from datetime import datetime, timedelta

def lambda_handler(event, context):
    client = boto3.client('cloudwatch')
    
    awsARN = os.environ["AWSConnectARN"]
    contactFlowARN = os.environ["SalesforceRestAPIFlowARN"]
    
    # Determine timeframe length and unit from the event
    timeframeLength = event.get('timeframeLength', "")
    timeframeUnit = event.get('timeframeUnit', "")
    
    # Define the time range
    end_time = datetime.now()
    if timeframeLength and timeframeUnit:
        dateArgs = {timeframeUnit: int(timeframeLength)}
        start_time = end_time - timedelta(**dateArgs)
    else:
        start_time = end_time - timedelta(weeks=2)
    
    # Define the parameters for the get_metric_data call
    params = {
        'StartTime': start_time,
        'EndTime': end_time,
        'MetricDataQueries': [
            {
                'Id': 'calls_per_interval',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'CallsPerInterval',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'VoiceCalls'}
                        ]
                    },
                    'Period': 60,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'missed_calls',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'MissedCalls',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'VoiceCalls'}
                        ]
                    },
                    'Period': 60,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'calls_breaching_concurrency_quota',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'CallsBreachingConcurrencyQuota',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'VoiceCalls'}
                        ]
                    },
                    'Period': 60,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'call_recording_upload_error',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'CallRecordingUploadError',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'CallRecordings'}
                        ]
                    },
                    'Period': 60,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'chats_breaching_active_chat_quota',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'ChatsBreachingActiveChatQuota',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'Chats'}
                        ]
                    },
                    'Period': 300,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'concurrent_active_chats',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'ConcurrentActiveChats',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'Chats'}
                        ]
                    },
                    'Period': 300,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'contact_flow_errors',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'ContactFlowErrors',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'ContactFlow'},
                            {'Name': 'ContactFlowName', 'Value': contactFlowARN}
                        ]
                    },
                    'Period': 300,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'contact_flow_fatal_errors',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'ContactFlowFatalErrors',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'ContactFlow'},
                            {'Name': 'ContactFlowName', 'Value': contactFlowARN}
                        ]
                    },
                    'Period': 300,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'throttled_calls',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'ThrottledCalls',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'MetricGroup', 'Value': 'VoiceCalls'}
                        ]
                    },
                    'Period': 300,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            },
            {
                'Id': 'to_instance_packet_loss_rate',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Connect',
                        'MetricName': 'ToInstancePacketLossRate',
                        'Dimensions': [
                            {'Name': 'InstanceId', 'Value': awsARN},
                            {'Name': 'Participant', 'Value': 'Agent'},
                            {'Name': 'Type of Connection', 'Value': 'WebRTC'},
                            {'Name': 'Stream Type', 'Value': 'Voice'}
                        ]
                    },
                    'Period': 60,
                    'Stat': 'Sum',
                    'Unit': 'Count'
                },
                'ReturnData': True
            }
        ]
    }
    
    # Retrieve metric data
    metricDataResponse = client.get_metric_data(**params)
    allDataResponse = [metricDataResponse]

    # Handle pagination if necessary
    while "NextToken" in metricDataResponse:
        params["NextToken"] = metricDataResponse["NextToken"]
        newMetricDataResponse = client.get_metric_data(**params)
        allDataResponse.append(newMetricDataResponse)
        metricDataResponse = newMetricDataResponse
    
    # Format timestamps
    for element in allDataResponse:
        for metric in element['MetricDataResults']:
            metric['Timestamps'] = [datapoint.strftime("%m/%d %-I:%M %p") for datapoint in metric['Timestamps']]
    
    # Merge data
    mergedData = {}
    for element in allDataResponse:
        if element["ResponseMetadata"]["HTTPStatusCode"] == 200:
            for result in element["MetricDataResults"]:
                metric_id = result["Id"]
                if metric_id not in mergedData:
                    mergedData[metric_id] = {
                        "Id": metric_id,
                        "Label": result["Label"],
                        "Timestamps": [],
                        "Values": [],
                    }
                mergedData[metric_id]["Timestamps"].extend(result["Timestamps"])
                mergedData[metric_id]["Values"].extend(result["Values"])
    
    allMergedData = list(mergedData.values())
    
    return {
        "MetricDataResults": allMergedData
    }